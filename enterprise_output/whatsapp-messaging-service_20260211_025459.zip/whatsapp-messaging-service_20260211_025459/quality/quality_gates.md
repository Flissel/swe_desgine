# Quality Gate Summary

**Total Gates Checked:** 1
- ✅ Passed: 0
- ⚠️ Warnings: 0
- ❌ Failed: 1

---

### ❌ Quality Gate: pass1_to_pass2

**Status:** FAIL
**Timestamp:** 2026-02-12T17:08:36.964799

**Metrics:**

| Metric | Value | Threshold | Status |
|--------|-------|-----------|--------|
| completeness | 0.00% | - | ❌ |
| stakeholder_coverage | 90.00% | - | ✅ |
| min_requirements | 126 | 3 | ✅ |

**Details:**
- completeness: 0.00% below threshold 80.00%
- stakeholder_coverage: 90.00% meets threshold 90.00%
- min_requirements: 126 meets minimum 3

---

